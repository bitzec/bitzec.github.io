<?php

return [
    'domain' => 'bitzec.github.io',
    'work_path' => '/',
];
